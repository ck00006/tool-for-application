export default async function Page() {
 return (
    <h1>In DB</h1>
 )
}