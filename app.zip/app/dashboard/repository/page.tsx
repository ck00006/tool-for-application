export default async function Page() {
    return (
       <h1>In Git Repos</h1>
    )
}