// pages/index.js or wherever you need the table
import DataTable from './components/common/DataTable';
import React from 'react';
import Link from 'next/link';
import clsx from 'clsx';
import {
    TvIcon
  } from '@heroicons/react/24/outline';
const data = {
  metadata: [
    { name: 'Column X' },
    { name: 'Column Y' }
  ],
  rows: [
    [120, 130],
    [200, 210]
  ]
};

const Home = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-blue-400 text-white p-4">
      <Link
            key={'Dashboard'}
            href={'/dashboard'}
            className={clsx(
              'flex h-[48px] grow items-center justify-center gap-2 rounded-md  p-3 text-sm font-medium hover:text-blue-600 md:flex-none md:justify-start md:p-2 md:px-3'
            )}
          >
            <TvIcon className="w-6" />
            <p className="hidden md:block">{'Dashboard'}</p>
          </Link>
      </header>
      <main className="flex-1 p-4">
        <DataTable data={data} />
      </main>
      <footer className="bg-blue-400 text-white p-4">
        {/* ... */}
      </footer>
    </div>
  );
};

export default Home;
