'use client'
import React, { useState, useEffect, useMemo } from 'react';

const DataTable = ({ data }: any) => {
  const { metadata, rows } = data;
  const [sortColumn, setSortColumn] = useState<any>(null);
  const [sortDirection, setSortDirection] = useState('asc');
  const [filterQuery, setFilterQuery] = useState('');
  const [displayedRows, setDisplayedRows] = useState([]);
  const [loadMoreLimit, setLoadMoreLimit] = useState(20);

  const sortedRows = useMemo(() => {
    //if (!sortColumn) return rows;

    return [...rows].sort((a, b) => {
      if (a[sortColumn] < b[sortColumn]) return sortDirection === 'asc' ? -1 : 1;
      if (a[sortColumn] > b[sortColumn]) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [rows, sortColumn, sortDirection]);

  const filteredRows: any = useMemo(() => {
    if (!filterQuery) return sortedRows;

    return sortedRows.filter((row) =>
      row.some((cell: any) =>
        cell.toString().toLowerCase().includes(filterQuery.toLowerCase())
      )
    );
  }, [sortedRows, filterQuery]);

  useEffect(() => {
    setDisplayedRows(filteredRows.slice(0, loadMoreLimit));
  }, [filteredRows, loadMoreLimit]);

  const handleLoadMore = () => {
    setLoadMoreLimit(loadMoreLimit + 20);
  };

  return (
    <div>
      <input
        type="text"
        className="mb-4 p-2 border rounded"
        placeholder="Filter..."
        value={filterQuery}
        onChange={(e) => setFilterQuery(e.target.value)}
      />
      <div className="overflow-x-auto relative">
        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              {metadata.map((header: any, index: any) => (
                <th
                  key={index}
                  scope="col"
                  className="py-3 px-6 cursor-pointer"
                  onClick={(e: any) => {
                    if (sortColumn === index) {
                      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                    } else {
                      setSortColumn(index);
                      setSortDirection('asc');
                    }
                  }}
                >
                  {header.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {displayedRows.map((row :any, rowIndex: any) => (
              <tr key={rowIndex} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                {row.map((cell: any, cellIndex: any) => (
                  <td key={cellIndex} className="py-4 px-6">
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        <button
          onClick={handleLoadMore}
          className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Load More
        </button>
      </div>
    </div>
  );
};

export default DataTable;
